# Canonical / Header

## 📸 Visual Reference

The Header is a persistent top navigation bar that spans the full width of the application. It contains:
- Left section: Menu icon + Couppa logo
- Right section: Search bar + Home icon + Notification bell (with badge) + User avatar

---

## 📐 Specifications

### Layout
- **Width**: 100% (full width)
- **Height**: Auto (based on content padding)
- **Background**: `var(--card)` (#FFFFFF)
- **Border**: Bottom border `var(--border)` (#D0D5DD)
- **Shadow**: `var(--elevation-sm)`
- **Padding**: `px-6 py-2.5`

### Elements

#### Menu Icon (Button)
- **Size**: 24x24px
- **Color**: `var(--foreground)` (#101828)
- **Hover**: opacity-70

#### Logo
- **Height**: 32px (h-8)
- **Width**: 117.7px
- **Source**: `/assets/images/logo.png`

#### Search Bar
- **Width**: 320px
- **Background**: `var(--muted)` (#F2F4F7)
- **Border Radius**: 20px
- **Padding**: `pl-2 pr-3 py-1.5`
- **Placeholder**: "Tìm kiếm nhanh"
- **Icon Size**: 24x24px
- **Text Size**: `var(--text-sm)` (14px)
- **Text Color**: `#667085` (muted-foreground)

#### Home Icon Button
- **Size**: 24x24px icon + 8px padding = 40x40px total
- **Hover**: `bg-[#f9fafb]`

#### Bell Icon Button
- **Size**: 24x24px icon + 8px padding = 40x40px total
- **Hover**: `bg-[#f9fafb]`
- **Badge**: Red circle (#D11313) with white text
  - Position: Absolute top-0 left-5
  - Padding: `px-1 py-0.5`
  - Border radius: 10px
  - Font size: 12px

#### User Avatar
- **Size**: 36x36px (size-9)
- **Border Radius**: Full circle (rounded-full)
- **Source**: `/assets/images/avatar-default.png`

---

## 💻 Component Code

```tsx
import svgPaths from '@/imports/svg-s0hhxgnsca';
import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

export function Header() {
  return (
    <div className="bg-white relative w-full shrink-0">
      {/* Border and shadow overlay */}
      <div 
        aria-hidden="true" 
        className="absolute border-[#d0d5dd] border-[0px_0px_1px] border-solid inset-0 pointer-events-none shadow-[0px_1px_3px_0px_rgba(16,24,40,0.1),0px_1px_2px_0px_rgba(16,24,40,0.06)]" 
      />
      
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center px-6 py-2.5 relative w-full">
          {/* Left Section: Menu + Logo */}
          <div className="basis-0 content-stretch flex gap-6 grow items-center min-h-px min-w-px relative shrink-0">
            {/* Menu Icon */}
            <button className="relative shrink-0 size-6 hover:opacity-70 transition-opacity">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
                <g>
                  <path 
                    d="M3 12H21M3 6H21M3 18H21" 
                    stroke="var(--stroke-0, #101828)" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth="1.5" 
                  />
                </g>
              </svg>
            </button>
            
            {/* Logo */}
            <div className="h-8 relative shrink-0 w-[117.7px]">
              <ImageWithFallback 
                alt="Couppa" 
                className="absolute inset-0 max-w-none object-center object-cover pointer-events-none size-full" 
                src="/assets/images/logo.png" 
              />
            </div>
          </div>

          {/* Right Section: Search + Icons + Avatar */}
          <div className="content-stretch flex gap-4 items-center relative shrink-0">
            {/* Search Bar */}
            <div className="bg-[#f2f4f7] content-stretch flex gap-2 items-center pl-2 pr-3 py-1.5 relative rounded-[20px] shrink-0 w-[320px]">
              {/* Search Icon */}
              <div className="overflow-clip relative shrink-0 size-6">
                <div className="absolute inset-[8.33%]">
                  <div className="absolute inset-[0_-3.75%_-3.75%_0]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.75 20.75">
                      <g>
                        <path 
                          d="M15.5556 15.5556L20 20" 
                          stroke="var(--stroke-0, #101828)" 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          strokeWidth="1.5" 
                        />
                        <circle 
                          cx="9.44444" 
                          cy="9.44444" 
                          r="8.69444" 
                          stroke="var(--stroke-0, #101828)" 
                          strokeWidth="1.5" 
                        />
                      </g>
                    </svg>
                  </div>
                </div>
              </div>
              
              <input
                type="text"
                placeholder="Tìm kiếm nhanh"
                className="basis-0 bg-transparent border-none outline-none font-normal grow leading-5 min-h-px min-w-px not-italic relative shrink-0 text-[#667085] text-sm placeholder:text-[#667085]"
              />
              
              <p className="font-normal leading-5 not-italic relative shrink-0 text-[#667085] text-sm text-nowrap">
                Ctrl S
              </p>
            </div>

            {/* Home + Bell + Avatar */}
            <div className="content-stretch flex gap-3 items-center relative shrink-0">
              {/* Home Icon */}
              <button className="content-stretch flex items-start p-2 relative shrink-0 hover:bg-[#f9fafb] rounded transition-colors">
                <div className="relative shrink-0 size-6">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
                    <g>
                      <path 
                        d={svgPaths.p996d900} 
                        stroke="var(--stroke-0, #101828)" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth="1.5" 
                      />
                    </g>
                  </svg>
                </div>
              </button>

              {/* Bell Icon with Badge */}
              <button className="relative content-stretch flex gap-2 items-start p-2 shrink-0 hover:bg-[#f9fafb] rounded transition-colors">
                <div className="relative shrink-0 size-6">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
                    <g>
                      <path 
                        d={svgPaths.p2fb08800} 
                        stroke="var(--stroke-0, #101828)" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth="1.5" 
                      />
                    </g>
                  </svg>
                </div>
                
                {/* Badge */}
                <div className="absolute bg-[#d11313] content-stretch flex flex-col items-center justify-center left-5 px-1 py-0.5 rounded-[10px] top-0">
                  <p className="font-normal leading-3 not-italic relative shrink-0 text-xs text-nowrap text-white">
                    8
                  </p>
                </div>
              </button>

              {/* Avatar */}
              <button className="relative shrink-0 size-9">
                <ImageWithFallback 
                  alt="User" 
                  className="block max-w-none size-full rounded-full object-cover" 
                  src="/assets/images/avatar-default.png" 
                />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
```

---

## 🎛️ Props API

To make this component reusable, here's a proposed props interface:

```tsx
interface HeaderProps {
  // Logo
  logoSrc?: string;
  logoAlt?: string;
  
  // Search
  searchPlaceholder?: string;
  searchValue?: string;
  onSearchChange?: (value: string) => void;
  searchShortcut?: string;
  
  // Actions
  onMenuClick?: () => void;
  onHomeClick?: () => void;
  onNotificationClick?: () => void;
  onAvatarClick?: () => void;
  
  // Notifications
  notificationCount?: number;
  
  // User
  userAvatar?: string;
  userName?: string;
}
```

---

## 📝 Usage Examples

### Basic Usage
```tsx
import { Header } from '@/app/components/Header';

function App() {
  return (
    <div>
      <Header />
      {/* Page content */}
    </div>
  );
}
```

### With Props
```tsx
<Header
  searchPlaceholder="Search..."
  searchValue={searchQuery}
  onSearchChange={setSearchQuery}
  notificationCount={12}
  onMenuClick={() => toggleSidebar()}
  onNotificationClick={() => openNotifications()}
/>
```

---

## 🎨 Variants

### 1. Default (Current)
Full header with all elements

### 2. Minimal
Without search bar (mobile view)

### 3. With User Name
Display user name next to avatar

---

## 🔧 Customization with CSS Variables

All colors can be customized by updating `/src/styles/theme.css`:

```css
:root {
  --card: rgba(255, 255, 255, 1);        /* Header background */
  --border: rgba(208, 213, 221, 1);       /* Bottom border */
  --muted: rgba(242, 244, 247, 1);        /* Search bar background */
  --muted-foreground: rgba(102, 112, 133, 1); /* Search text */
  --foreground: rgba(16, 24, 40, 1);      /* Icon color */
}
```

---

## ♿ Accessibility

- All buttons have hover states for visual feedback
- Icon buttons have proper `aria-label` attributes (should be added)
- Search input has placeholder text
- Keyboard navigation supported
- Avatar has alt text for screen readers

---

## 📱 Responsive Behavior

**Desktop (default)**: Full header with all elements
**Tablet**: Same layout, search bar might shrink
**Mobile**: Consider hiding search bar or making it a modal

---

## 🐛 Known Issues / Improvements

1. SVG paths are imported from external file - consider using lucide-react icons instead
2. Add aria-labels to all buttons
3. Make search functional with keyboard shortcuts
4. Add dropdown menu for avatar click
5. Add notification panel for bell icon click
6. Consider making menu icon toggle sidebar state

---

**Source File**: `/src/app/components/Header.tsx`
**Last Updated**: January 15, 2026

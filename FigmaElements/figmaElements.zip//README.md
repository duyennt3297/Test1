# Canonical Elements Library

This library contains all reusable UI elements extracted from the Couppa application. Each element is documented with exact specifications, code implementation, and usage examples.

## 📐 Design System

All elements follow the design system defined in `/src/styles/theme.css`:

### Colors
- **Primary**: `var(--primary)` - #7F56D9 (purple)
- **Background**: `var(--background)` - #F9FAFB
- **Card**: `var(--card)` - #FFFFFF
- **Border**: `var(--border)` - #D0D5DD
- **Destructive**: `var(--destructive)` - #D92D20
- **Muted**: `var(--muted)` - #F2F4F7

### Typography
- **Font Family**: 'Inter', sans-serif
- **Text Sizes**: 
  - `--text-xs`: 12px
  - `--text-sm`: 14px
  - `--text-base`: 16px
  - `--text-lg`: 20px
  - `--text-xl`: 24px
  - `--text-2xl`: 30px
- **Font Weights**:
  - `--font-weight-normal`: 400
  - `--font-weight-medium`: 500
  - `--font-weight-semibold`: 600
  - `--font-weight-bold`: 700

### Spacing & Layout
- **Border Radius**: `--radius`: 8px
- **Card Radius**: `--radius-card`: 16px
- **Shadow**: `--elevation-sm`

---

## 📦 Element Categories

### Navigation Elements
1. [Header](#canonical-header) - Top navigation bar with search and user actions
2. [Sidebar](#canonical-sidebar) - Collapsible sidebar navigation with menu hierarchy
3. [Breadcrumb](#canonical-breadcrumb) - Navigation breadcrumb trail

### Data Display
4. [Stats Card](#canonical-stats-card) - Metric display card with icon
5. [Data Table](#canonical-data-table) - Sortable, filterable data table
6. [Product Card](#canonical-product-card) - Product listing item with image and details
7. [Status Badge](#canonical-status-badge) - Colored status indicators

### Form Elements
8. [Search Input](#canonical-search-input) - Search bar with icon
9. [Select Dropdown](#canonical-select-dropdown) - Styled dropdown selector
10. [Filter Bar](#canonical-filter-bar) - Combined filter controls
11. [Primary Button](#canonical-primary-button) - Call-to-action button
12. [Icon Button](#canonical-icon-button) - Icon-only action button

### Feedback Elements
13. [Confirm Dialog](#canonical-confirm-dialog) - Confirmation modal
14. [Loading State](#canonical-loading-state) - Loading spinner
15. [Empty State](#canonical-empty-state) - No data placeholder

### Table Components
16. [Pagination](#canonical-pagination) - Table pagination controls
17. [Action Bar](#canonical-action-bar) - Bulk action toolbar

---

## 📋 Element Index

| Element Name | Category | Used In | Component File |
|--------------|----------|---------|----------------|
| Header | Navigation | All pages | `Header.tsx` |
| Sidebar | Navigation | All pages | `Sidebar.tsx` |
| Stats Card | Data Display | ProductsList, Dashboard | `ProductsList.tsx` |
| Data Table | Data Display | VideoTable, ProductsList | `VideoTable.tsx` |
| Status Badge | Data Display | VideoTable, ProductsList | Inline |
| Search Input | Forms | Header, ProductsList | Multiple |
| Filter Bar | Forms | VideoTable | `VideoTable.tsx` |
| Primary Button | Forms | All pages | `ui/button.tsx` |
| Confirm Dialog | Feedback | VideoTable | `ConfirmDialog.tsx` |
| Pagination | Table | VideoTable | `VideoTable.tsx` |
| Action Bar | Table | VideoTable | `VideoTable.tsx` |

---

## 🎯 Usage Guidelines

### 1. Always Use CSS Variables
```tsx
// ✅ CORRECT
<div className="bg-card border-border rounded-lg">

// ❌ WRONG
<div className="bg-white border-[#D0D5DD] rounded-lg">
```

### 2. Typography
```tsx
// ✅ CORRECT - Using CSS variables
<h1 style={{ fontSize: 'var(--text-2xl)', fontWeight: 'var(--font-weight-semibold)' }}>

// ❌ WRONG - Hardcoded values
<h1 className="text-[30px] font-semibold">
```

### 3. Spacing
Use Tailwind spacing classes which are already integrated with the design system:
- `gap-2`, `gap-3`, `gap-4`
- `p-4`, `px-6`, `py-2`

### 4. Icons
Always use `lucide-react` for icons:
```tsx
import { Plus, Search, Trash2 } from 'lucide-react';
```

---

## 🔄 Reusability Principles

1. **Self-contained**: Each element can work independently
2. **Props-based**: Customize via props, not hardcoded values
3. **CSS Variables**: All colors/sizes use design tokens
4. **Accessible**: Proper ARIA labels and keyboard navigation
5. **Responsive**: Mobile-first responsive design

---

## 📖 Detailed Documentation

Each element has its own detailed page with:
- **Visual Reference** - Screenshot or description
- **Specifications** - Exact sizes, colors, spacing
- **Component Code** - Full React implementation
- **Props API** - All available props and types
- **Usage Examples** - Real-world implementation examples
- **Variants** - Different states and variations

---

## 🚀 Quick Start

To use a canonical element in your project:

1. Copy the component code from the element's documentation page
2. Ensure you have the design system CSS imported
3. Install required dependencies (lucide-react, etc.)
4. Import and use the component

```tsx
import { CanonicalHeader } from '@/docs/canonicalElements/Header';

function MyPage() {
  return (
    <div>
      <CanonicalHeader />
      {/* Your content */}
    </div>
  );
}
```

---

## 📝 Notes

- All elements were extracted from the production Couppa application
- Design tokens defined in `/src/styles/theme.css`
- Font: Inter (loaded via `/src/styles/fonts.css`)
- Tested on Chrome, Firefox, Safari, Edge
- Mobile responsive (breakpoints: sm, md, lg, xl)

---

Last Updated: January 15, 2026

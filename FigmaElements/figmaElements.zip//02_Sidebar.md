# Canonical / Sidebar

## 📸 Visual Reference

Vertical navigation sidebar with collapsible menu groups. Features hierarchical navigation with parent items and nested children.

**Structure**:
- Dashboard (single item)
- Products (expandable)
  - List
  - Create
- Setting (expandable)
  - Account
  - Settings
- Files (expandable)
  - Files
  - Folders
  - Storage

---

## 📐 Specifications

### Container
- **Width**: 200px fixed
- **Height**: 100vh (full viewport height)
- **Background**: `var(--card)` (#FFFFFF)
- **Border Right**: `var(--sidebar-border)` (#EAECF0)
- **Padding**: 8px (p-2)

### Menu Items

#### Parent Menu Item
- **Width**: 100%
- **Padding**: `px-3 py-2` (12px horizontal, 8px vertical)
- **Border Radius**: `rounded-lg` (8px)
- **Gap**: 8px (gap-2)
- **Font Size**: `var(--text-sm)` (14px)
- **Font Weight**: 
  - Active: `var(--font-weight-medium)` (500)
  - Inactive: `var(--font-weight-normal)` (400)

**States**:
- **Default**: `text-sidebar-foreground`, hover `bg-muted`
- **Active**: `bg-destructive text-destructive-foreground`
- **Icon Size**: 16x16px (w-4 h-4)
- **Chevron Size**: 12x12px (w-3 h-3)

#### Child Menu Item
- **Width**: 100%
- **Padding**: `px-3 py-1.5` (12px horizontal, 6px vertical)
- **Margin Left**: 24px (ml-6) for indentation
- **Border Radius**: `rounded-lg` (8px)
- **Font Size**: `var(--text-sm)` (14px)

**States**:
- **Default**: `text-muted-foreground`, hover `text-foreground bg-muted`
- **Active**: `text-destructive`

### Spacing
- **Gap between items**: 4px (mb-1)
- **Gap between icon and text**: 8px (gap-2)
- **Child item top margin**: 4px (mt-1)

---

## 💻 Component Code

```tsx
import { 
  LayoutDashboard, 
  ChevronDown,
  FolderOpen,
  HardDrive,
  Tags,
  Package,
  Settings
} from 'lucide-react';
import { useState } from 'react';

interface SidebarProps {
  activeMenu: string;
  onMenuClick: (menu: string) => void;
}

export function Sidebar({ activeMenu, onMenuClick }: SidebarProps) {
  const [filesExpanded, setFilesExpanded] = useState(true);
  const [productsExpanded, setProductsExpanded] = useState(true);
  const [settingExpanded, setSettingExpanded] = useState(false);

  const isFilesActive = ['files', 'folders', 'storage'].includes(activeMenu);
  const isProductsActive = ['products-list', 'products-create'].includes(activeMenu);
  const isSettingActive = ['account', 'settings'].includes(activeMenu);

  return (
    <div className="w-[200px] bg-card border-r border-sidebar-border h-screen flex flex-col">
      {/* Menu Items */}
      <div className="flex-1 overflow-y-auto p-2" style={{ fontSize: 'var(--text-sm)' }}>
        <button
          key="dashboard"
          onClick={() => onMenuClick('dashboard')}
          className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg mb-1 transition-colors ${
            activeMenu === 'dashboard' 
              ? 'bg-destructive text-destructive-foreground' 
              : 'text-sidebar-foreground hover:bg-muted'
          }`}
          style={{
            fontWeight: activeMenu === 'dashboard' ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
          }}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Dashboard</span>
        </button>

        {/* Products Menu */}
        <div className="mb-1">
          <button
            onClick={() => setProductsExpanded(!productsExpanded)}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
              isProductsActive
                ? 'bg-destructive text-destructive-foreground'
                : 'text-sidebar-foreground hover:bg-muted'
            }`}
            style={{
              fontWeight: isProductsActive ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
            }}
          >
            <Package className="w-4 h-4" />
            <span className="flex-1 text-left">Products</span>
            <ChevronDown className={`w-3 h-3 transition-transform ${productsExpanded ? 'rotate-180' : ''}`} />
          </button>
          {productsExpanded && (
            <div className="ml-6 mt-1">
              <button
                onClick={() => onMenuClick('products-list')}
                className={`w-full text-left px-3 py-1.5 rounded-lg ${
                  activeMenu === 'products-list' 
                    ? 'text-destructive' 
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
                style={{
                  fontSize: 'var(--text-sm)',
                  fontWeight: activeMenu === 'products-list' ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
                }}
              >
                List
              </button>
              <button
                onClick={() => onMenuClick('products-create')}
                className={`w-full text-left px-3 py-1.5 rounded-lg ${
                  activeMenu === 'products-create' 
                    ? 'text-destructive' 
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
                style={{
                  fontSize: 'var(--text-sm)',
                  fontWeight: activeMenu === 'products-create' ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
                }}
              >
                Create
              </button>
            </div>
          )}
        </div>

        {/* Setting Menu */}
        <div className="mb-1">
          <button
            onClick={() => setSettingExpanded(!settingExpanded)}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
              isSettingActive 
                ? 'bg-destructive text-destructive-foreground' 
                : 'text-sidebar-foreground hover:bg-muted'
            }`}
            style={{
              fontWeight: isSettingActive ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
            }}
          >
            <Settings className="w-4 h-4" />
            <span className="flex-1 text-left">Setting</span>
            <ChevronDown className={`w-3 h-3 transition-transform ${settingExpanded ? 'rotate-180' : ''}`} />
          </button>
          {settingExpanded && (
            <div className="ml-6 mt-1">
              <button
                onClick={() => onMenuClick('account')}
                className={`w-full text-left px-3 py-1.5 rounded-lg ${
                  activeMenu === 'account' 
                    ? 'text-destructive' 
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
                style={{
                  fontSize: 'var(--text-sm)',
                  fontWeight: activeMenu === 'account' ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
                }}
              >
                Account
              </button>
              <button
                onClick={() => onMenuClick('settings')}
                className={`w-full text-left px-3 py-1.5 rounded-lg ${
                  activeMenu === 'settings' 
                    ? 'text-destructive' 
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
                style={{
                  fontSize: 'var(--text-sm)',
                  fontWeight: activeMenu === 'settings' ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
                }}
              >
                Settings
              </button>
            </div>
          )}
        </div>

        {/* Files Menu */}
        <div className="mb-1">
          <button
            onClick={() => setFilesExpanded(!filesExpanded)}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
              isFilesActive
                ? 'bg-destructive text-destructive-foreground'
                : 'text-sidebar-foreground hover:bg-muted'
            }`}
            style={{
              fontWeight: isFilesActive ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
            }}
          >
            <FolderOpen className="w-4 h-4" />
            <span className="flex-1 text-left">Files</span>
            <ChevronDown className={`w-3 h-3 transition-transform ${filesExpanded ? 'rotate-180' : ''}`} />
          </button>
          {filesExpanded && (
            <div className="ml-6 mt-1">
              <button
                onClick={() => onMenuClick('files')}
                className={`w-full text-left px-3 py-1.5 rounded-lg ${
                  activeMenu === 'files' 
                    ? 'text-destructive' 
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
                style={{
                  fontSize: 'var(--text-sm)',
                  fontWeight: activeMenu === 'files' ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
                }}
              >
                Files
              </button>
              <button
                onClick={() => onMenuClick('folders')}
                className={`w-full text-left px-3 py-1.5 rounded-lg ${
                  activeMenu === 'folders' 
                    ? 'text-destructive' 
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
                style={{
                  fontSize: 'var(--text-sm)',
                  fontWeight: activeMenu === 'folders' ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
                }}
              >
                Folders
              </button>
              <button
                onClick={() => onMenuClick('storage')}
                className={`w-full text-left px-3 py-1.5 rounded-lg ${
                  activeMenu === 'storage' 
                    ? 'text-destructive' 
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
                style={{
                  fontSize: 'var(--text-sm)',
                  fontWeight: activeMenu === 'storage' ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
                }}
              >
                Storage
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
```

---

## 🎛️ Props API

```tsx
interface MenuItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  children?: {
    id: string;
    label: string;
  }[];
}

interface SidebarProps {
  // Current active menu item ID
  activeMenu: string;
  
  // Callback when menu item is clicked
  onMenuClick: (menuId: string) => void;
  
  // Optional: Custom menu structure
  menuItems?: MenuItem[];
  
  // Optional: Default expanded state
  defaultExpanded?: string[];
  
  // Optional: Width
  width?: number | string;
}
```

---

## 📝 Usage Examples

### Basic Usage
```tsx
import { Sidebar } from '@/app/components/Sidebar';
import { useState } from 'react';

function App() {
  const [activeMenu, setActiveMenu] = useState('dashboard');
  
  return (
    <div className="flex">
      <Sidebar 
        activeMenu={activeMenu}
        onMenuClick={setActiveMenu}
      />
      {/* Page content */}
    </div>
  );
}
```

### With Custom Menu Items
```tsx
const customMenuItems = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
  },
  {
    id: 'products',
    label: 'Products',
    icon: Package,
    children: [
      { id: 'products-list', label: 'List' },
      { id: 'products-create', label: 'Create' },
    ],
  },
];

<Sidebar
  activeMenu={activeMenu}
  onMenuClick={setActiveMenu}
  menuItems={customMenuItems}
/>
```

---

## 🎨 Variants

### 1. Default (200px)
Standard sidebar width

### 2. Collapsed (60px)
Show only icons, hide text

### 3. Wide (280px)
Larger sidebar for more content

---

## 🔧 Customization with CSS Variables

```css
:root {
  --card: rgba(255, 255, 255, 1);              /* Sidebar background */
  --sidebar-border: rgba(234, 236, 240, 1);    /* Right border */
  --sidebar-foreground: rgba(16, 24, 40, 1);   /* Text color */
  --muted: rgba(242, 244, 247, 1);             /* Hover background */
  --muted-foreground: rgba(102, 112, 133, 1);  /* Child text color */
  --destructive: rgba(217, 45, 32, 1);         /* Active background */
  --destructive-foreground: rgba(255, 255, 255, 1); /* Active text */
}
```

---

## ♿ Accessibility

- Keyboard navigation with Tab/Shift+Tab
- Enter/Space to expand/collapse sections
- Arrow keys for navigation
- Focus visible states
- Proper ARIA attributes for expandable sections

---

## 📱 Responsive Behavior

**Desktop**: Full sidebar visible
**Tablet**: Consider collapsible sidebar
**Mobile**: Hidden by default, show as overlay/drawer when menu icon clicked

---

## 🔄 State Management

```tsx
// Parent menu expansion states
const [filesExpanded, setFilesExpanded] = useState(true);
const [productsExpanded, setProductsExpanded] = useState(true);
const [settingExpanded, setSettingExpanded] = useState(false);

// Active menu detection
const isFilesActive = ['files', 'folders', 'storage'].includes(activeMenu);
const isProductsActive = ['products-list', 'products-create'].includes(activeMenu);
```

---

## 🐛 Known Issues / Improvements

1. Consider using React Context for activeMenu state
2. Add collapse/expand all functionality
3. Add badge support for notifications (e.g., "Files (3)")
4. Add tooltip for collapsed state
5. Persist expansion state in localStorage
6. Add drag-and-drop to reorder menu items
7. Support nested levels beyond 2

---

**Source File**: `/src/app/components/Sidebar.tsx`
**Dependencies**: `lucide-react`
**Last Updated**: January 15, 2026

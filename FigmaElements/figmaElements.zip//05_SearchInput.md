# Canonical / Search Input

## 📸 Visual Reference

A search input field with an icon on the left side. Two main variants exist in the application:
1. **Header Search** - Rounded pill-shaped with gray background and keyboard shortcut
2. **Filter Search** - Standard rectangular with white background and divider before icon

---

## 📐 Specifications

### Header Search Variant
- **Width**: 320px
- **Height**: Auto (content-based)
- **Background**: `var(--muted)` (#F2F4F7)
- **Border**: None
- **Border Radius**: 20px (rounded-[20px])
- **Padding**: `pl-2 pr-3 py-1.5`
- **Icon Size**: 24x24px (size-6)
- **Text Size**: `var(--text-sm)` (14px)
- **Placeholder Color**: `var(--muted-foreground)` (#667085)

**Elements**:
- Left: Search icon (24x24px)
- Center: Input field (flex-grow)
- Right: Keyboard shortcut text (e.g., "Ctrl S")

### Filter Search Variant
- **Width**: 400px or flexible
- **Height**: Auto
- **Background**: `var(--card)` (#FFFFFF)
- **Border**: 1px solid `var(--border)` (#D0D5DD)
- **Border Radius**: `rounded-lg` (8px)
- **Padding**: `px-3 py-2 pr-10`
- **Icon Position**: Absolute right
- **Divider**: 1px vertical line before icon

**States**:
- **Focus**: `focus:outline-none focus:border-[#98A2B3]`
- **Hover**: `hover:border-[#98A2B3]`

---

## 💻 Component Code

### Header Search Version
```tsx
import { Search } from 'lucide-react';

interface SearchInputProps {
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  shortcut?: string;
}

export function HeaderSearchInput({ 
  value = '', 
  onChange, 
  placeholder = 'Tìm kiếm nhanh',
  shortcut = 'Ctrl S'
}: SearchInputProps) {
  return (
    <div className="bg-[#f2f4f7] content-stretch flex gap-2 items-center pl-2 pr-3 py-1.5 relative rounded-[20px] shrink-0 w-[320px]">
      {/* Search Icon */}
      <div className="overflow-clip relative shrink-0 size-6">
        <Search className="w-full h-full text-[#101828]" strokeWidth={1.5} />
      </div>
      
      {/* Input */}
      <input
        type="text"
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        placeholder={placeholder}
        className="basis-0 bg-transparent border-none outline-none font-normal grow leading-5 min-h-px min-w-px not-italic relative shrink-0 text-[#667085] text-sm placeholder:text-[#667085]"
      />
      
      {/* Keyboard Shortcut */}
      {shortcut && (
        <p className="font-normal leading-5 not-italic relative shrink-0 text-[#667085] text-sm text-nowrap">
          {shortcut}
        </p>
      )}
    </div>
  );
}
```

### Filter Search Version
```tsx
import { Search } from 'lucide-react';

interface FilterSearchInputProps {
  value?: string;
  onChange?: (value: string) => void;
  onSearch?: () => void;
  placeholder?: string;
  width?: string;
}

export function FilterSearchInput({ 
  value = '', 
  onChange, 
  onSearch,
  placeholder = 'Tiêu đề',
  width = 'w-[400px]'
}: FilterSearchInputProps) {
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      onSearch?.();
    }
  };

  return (
    <div className={`relative ${width}`}>
      <input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        onKeyPress={handleKeyPress}
        className="w-full px-3 py-2 pr-10 bg-white border border-[#D0D5DD] rounded-lg text-[#667085] text-sm focus:outline-none focus:border-[#98A2B3] hover:border-[#98A2B3] transition-colors"
      />
      <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
        <div className="w-px h-6 bg-[#D0D5DD]" />
        <Search className="w-5 h-5 text-[#344054]" />
      </div>
    </div>
  );
}
```

### Simple Search Version
```tsx
import { Search } from 'lucide-react';

export function SimpleSearchInput({ 
  value = '', 
  onChange, 
  onSearch,
  placeholder = 'Search products...',
  width = 'w-[320px]'
}: FilterSearchInputProps) {
  return (
    <div className={`relative ${width}`}>
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#667085]" />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        onKeyPress={(e) => e.key === 'Enter' && onSearch?.()}
        placeholder={placeholder}
        className="pl-10 pr-4 py-2 w-full border border-[#D0D5DD] rounded-[8px] text-[14px] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-[#2563EB]"
      />
    </div>
  );
}
```

---

## 🎛️ Props API

```tsx
interface SearchInputProps {
  // Current search value
  value?: string;
  
  // Change handler
  onChange?: (value: string) => void;
  
  // Search button click or Enter key handler
  onSearch?: () => void;
  
  // Placeholder text
  placeholder?: string;
  
  // Optional: Width class
  width?: string;
  
  // Optional: Keyboard shortcut display (Header variant only)
  shortcut?: string;
  
  // Optional: Variant
  variant?: 'header' | 'filter' | 'simple';
  
  // Optional: Auto-focus on mount
  autoFocus?: boolean;
  
  // Optional: Debounce delay in ms
  debounceDelay?: number;
  
  // Optional: Clear button
  clearable?: boolean;
}
```

---

## 📝 Usage Examples

### Header Search
```tsx
import { HeaderSearchInput } from '@/app/components/SearchInput';
import { useState } from 'react';

function Header() {
  const [searchQuery, setSearchQuery] = useState('');
  
  return (
    <HeaderSearchInput
      value={searchQuery}
      onChange={setSearchQuery}
      placeholder="Tìm kiếm nhanh"
      shortcut="Ctrl S"
    />
  );
}
```

### Filter Search
```tsx
import { FilterSearchInput } from '@/app/components/SearchInput';

function VideoTable() {
  const [searchQuery, setSearchQuery] = useState('');
  
  const handleSearch = () => {
    console.log('Searching for:', searchQuery);
    // Perform search
  };
  
  return (
    <FilterSearchInput
      value={searchQuery}
      onChange={setSearchQuery}
      onSearch={handleSearch}
      placeholder="Tiêu đề"
      width="w-[400px]"
    />
  );
}
```

### Simple Search
```tsx
<SimpleSearchInput
  value={searchQuery}
  onChange={setSearchQuery}
  onSearch={loadProducts}
  placeholder="Search products..."
  width="w-[320px]"
/>
```

### With Debounce
```tsx
import { useState, useEffect } from 'react';
import { debounce } from 'lodash';

function SearchableList() {
  const [searchQuery, setSearchQuery] = useState('');
  
  // Debounced search
  const debouncedSearch = debounce((query: string) => {
    console.log('Searching:', query);
    // API call here
  }, 300);
  
  useEffect(() => {
    debouncedSearch(searchQuery);
    return () => debouncedSearch.cancel();
  }, [searchQuery]);
  
  return (
    <SimpleSearchInput
      value={searchQuery}
      onChange={setSearchQuery}
      placeholder="Search..."
    />
  );
}
```

---

## 🎨 Variants

### 1. Header Search (Pill-shaped)
```tsx
<HeaderSearchInput
  placeholder="Tìm kiếm nhanh"
  shortcut="Ctrl S"
/>
```
- Gray background (#F2F4F7)
- Rounded pill shape (20px)
- Shows keyboard shortcut

### 2. Filter Search (With Divider)
```tsx
<FilterSearchInput
  placeholder="Tiêu đề"
  width="w-[400px]"
/>
```
- White background
- Vertical divider before icon
- Focus ring on interaction

### 3. Simple Search
```tsx
<SimpleSearchInput
  placeholder="Search products..."
/>
```
- Icon on the left
- Clean minimal design
- Focus ring

---

## 🔧 Customization with CSS Variables

Update colors via CSS variables:

```css
:root {
  --muted: rgba(242, 244, 247, 1);          /* Header search background */
  --muted-foreground: rgba(102, 112, 133, 1); /* Placeholder color */
  --card: rgba(255, 255, 255, 1);           /* Filter search background */
  --border: rgba(208, 213, 221, 1);         /* Border color */
  --foreground: rgba(16, 24, 40, 1);        /* Icon color */
}
```

---

## ♿ Accessibility

- Proper `aria-label` for search input
- Keyboard navigation (Tab to focus)
- Enter key to search
- Clear button accessible via keyboard
- Screen reader announcements for results

```tsx
<input
  type="text"
  aria-label="Search"
  role="searchbox"
  aria-describedby="search-hint"
  placeholder={placeholder}
  // ...
/>
```

---

## 📱 Responsive Behavior

### Header Search
```tsx
// Desktop: Full width (320px)
// Mobile: Collapse to icon only, expand on click

<div className="w-[320px] lg:w-[320px] md:w-[240px] sm:w-10">
```

### Filter Search
```tsx
// Desktop: 400px
// Tablet: 300px
// Mobile: 100%

<div className="w-full md:w-[300px] lg:w-[400px]">
```

---

## 🎨 Advanced Features

### With Clear Button
```tsx
export function SearchInputWithClear({ value, onChange, onClear }: SearchInputProps) {
  return (
    <div className="relative w-[320px]">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#667085]" />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        className="pl-10 pr-10 py-2 w-full border border-[#D0D5DD] rounded-[8px]"
      />
      {value && (
        <button
          onClick={onClear}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-[#667085] hover:text-[#344054]"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}
```

### With Search Button
```tsx
<div className="flex items-center gap-3">
  <FilterSearchInput
    value={searchQuery}
    onChange={setSearchQuery}
    width="w-[320px]"
  />
  <button
    onClick={handleSearch}
    className="px-4 py-2 bg-[#2563EB] text-white rounded-[8px] text-[14px] font-medium hover:opacity-90"
  >
    Search
  </button>
</div>
```

### With Autocomplete
```tsx
export function SearchWithAutocomplete({ suggestions }: { suggestions: string[] }) {
  const [showSuggestions, setShowSuggestions] = useState(false);
  
  return (
    <div className="relative">
      <SimpleSearchInput
        value={value}
        onChange={setValue}
        onFocus={() => setShowSuggestions(true)}
        onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
      />
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-[#D0D5DD] rounded-lg shadow-lg z-10">
          {suggestions.map(suggestion => (
            <button
              key={suggestion}
              className="w-full text-left px-4 py-2 hover:bg-[#F9FAFB] text-sm"
              onClick={() => {
                setValue(suggestion);
                setShowSuggestions(false);
              }}
            >
              {suggestion}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
```

---

## 🐛 Known Issues / Improvements

1. Add loading spinner when searching
2. Add recent searches dropdown
3. Add voice search support
4. Highlight search terms in results
5. Add filters/advanced search modal
6. Add search history persistence
7. Better mobile experience (fullscreen modal on mobile)

---

**Source Files**: 
- `/src/app/components/Header.tsx` (Header Search)
- `/src/app/components/VideoTable.tsx` (Filter Search)
- `/src/app/components/ProductsList.tsx` (Simple Search)
**Dependencies**: `lucide-react`
**Last Updated**: January 15, 2026

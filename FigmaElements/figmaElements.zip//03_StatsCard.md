# Canonical / Stats Card

## 📸 Visual Reference

A metric display card showing a statistic with an icon. Used in dashboards to display KPIs and key metrics.

**Example**: 
- Total Products: 245
- Active: 180
- Out of Stock: 12
- Inventory Value: 1,250,000₫

---

## 📐 Specifications

### Container
- **Background**: `var(--card)` (#FFFFFF)
- **Border**: 1px solid `var(--border)` (#EAECF0)
- **Border Radius**: `var(--radius-card)` (12px)
- **Padding**: 16px (p-4)
- **Layout**: Flexbox row, space-between

### Elements

#### Left Section (Text)
- **Label**:
  - Font Size: `var(--text-xs)` (12px)
  - Color: `var(--muted-foreground)` (#667085)
  - Margin Bottom: 4px (mb-1)
  
- **Value**:
  - Font Size: 24px
  - Font Weight: `var(--font-weight-bold)` (700)
  - Color: `var(--foreground)` (#101828)

#### Right Section (Icon)
- **Container**:
  - Size: 40x40px (w-10 h-10)
  - Border Radius: Full circle (rounded-full)
  - Display: flex center
  
- **Icon**:
  - Size: 20x20px (w-5 h-5)

### Color Variants

| Variant | Background | Icon Color | Use Case |
|---------|------------|------------|----------|
| Primary | `#EFF6FF` | `#2563EB` | Total/Main metrics |
| Success | `#ECFDF5` | `#047857` | Positive metrics |
| Danger | `#FEF2F2` | `#DC2626` | Alerts/Problems |
| Warning | `#FEF3C7` | `#F59E0B` | Money/Value |
| Gray | `#F3F4F6` | `#6B7280` | Neutral metrics |

---

## 💻 Component Code

```tsx
import { Package, TrendingUp, AlertTriangle, DollarSign, BarChart3 } from 'lucide-react';

interface StatsCardProps {
  label: string;
  value: string | number;
  icon: React.ComponentType<{ className?: string }>;
  variant?: 'primary' | 'success' | 'danger' | 'warning' | 'gray';
}

export function StatsCard({ label, value, icon: Icon, variant = 'primary' }: StatsCardProps) {
  const variantStyles = {
    primary: {
      bg: 'bg-[#EFF6FF]',
      iconColor: 'text-[#2563EB]',
    },
    success: {
      bg: 'bg-[#ECFDF5]',
      iconColor: 'text-[#047857]',
    },
    danger: {
      bg: 'bg-[#FEF2F2]',
      iconColor: 'text-[#DC2626]',
    },
    warning: {
      bg: 'bg-[#FEF3C7]',
      iconColor: 'text-[#F59E0B]',
    },
    gray: {
      bg: 'bg-[#F3F4F6]',
      iconColor: 'text-[#6B7280]',
    },
  };

  const styles = variantStyles[variant];

  return (
    <div className="bg-white rounded-[12px] border border-[#EAECF0] p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[12px] text-[#667085] mb-1">{label}</p>
          <p className="text-[24px] font-bold text-[#101828]">{value}</p>
        </div>
        <div className={`w-10 h-10 rounded-full ${styles.bg} flex items-center justify-center`}>
          <Icon className={`w-5 h-5 ${styles.iconColor}`} />
        </div>
      </div>
    </div>
  );
}
```

---

## 🎛️ Props API

```tsx
interface StatsCardProps {
  // Display label (e.g., "Total Products")
  label: string;
  
  // Display value (can be string or number)
  value: string | number;
  
  // Icon component from lucide-react
  icon: React.ComponentType<{ className?: string }>;
  
  // Visual variant
  variant?: 'primary' | 'success' | 'danger' | 'warning' | 'gray';
  
  // Optional: Click handler
  onClick?: () => void;
  
  // Optional: Show trend arrow
  trend?: {
    value: number;
    isPositive: boolean;
  };
  
  // Optional: Additional description
  description?: string;
}
```

---

## 📝 Usage Examples

### Basic Usage
```tsx
import { StatsCard } from '@/app/components/StatsCard';
import { Package } from 'lucide-react';

<StatsCard
  label="Total Products"
  value={245}
  icon={Package}
  variant="primary"
/>
```

### Grid Layout
```tsx
<div className="grid grid-cols-4 gap-4">
  <StatsCard
    label="Total Products"
    value={stats.total}
    icon={Package}
    variant="primary"
  />
  <StatsCard
    label="Active"
    value={stats.active}
    icon={TrendingUp}
    variant="success"
  />
  <StatsCard
    label="Out of Stock"
    value={stats.outOfStock}
    icon={AlertTriangle}
    variant="danger"
  />
  <StatsCard
    label="Inventory Value"
    value={formatCurrency(stats.totalValue)}
    icon={DollarSign}
    variant="warning"
  />
</div>
```

### With Trend
```tsx
<StatsCard
  label="Total Revenue"
  value="$12,450"
  icon={DollarSign}
  variant="success"
  trend={{ value: 12.5, isPositive: true }}
/>
```

---

## 🎨 Variants

### 1. Primary (Blue)
Used for main metrics like totals
```tsx
<StatsCard label="Total" value={100} icon={BarChart3} variant="primary" />
```

### 2. Success (Green)
Used for positive metrics
```tsx
<StatsCard label="Active" value={85} icon={TrendingUp} variant="success" />
```

### 3. Danger (Red)
Used for alerts and problems
```tsx
<StatsCard label="Out of Stock" value={5} icon={AlertTriangle} variant="danger" />
```

### 4. Warning (Yellow)
Used for financial metrics
```tsx
<StatsCard label="Value" value="$1,250" icon={DollarSign} variant="warning" />
```

### 5. Gray (Neutral)
Used for neutral metrics
```tsx
<StatsCard label="Pending" value={15} icon={Package} variant="gray" />
```

---

## 🔧 Customization with CSS Variables

To use CSS variables instead of hardcoded colors:

```tsx
const variantStyles = {
  primary: {
    bg: 'bg-primary/10',
    iconColor: 'text-primary',
  },
  success: {
    bg: 'bg-[#ECFDF5]',
    iconColor: 'text-[#047857]',
  },
  danger: {
    bg: 'bg-destructive/10',
    iconColor: 'text-destructive',
  },
  // ...
};
```

And update CSS:

```css
:root {
  --primary: rgba(37, 99, 235, 1);      /* Blue */
  --destructive: rgba(220, 38, 38, 1);  /* Red */
  --foreground: rgba(16, 24, 40, 1);    /* Value text */
  --muted-foreground: rgba(102, 112, 133, 1); /* Label text */
  --border: rgba(234, 236, 240, 1);     /* Border */
  --card: rgba(255, 255, 255, 1);       /* Background */
}
```

---

## ♿ Accessibility

- Use semantic HTML with proper heading levels
- Ensure sufficient color contrast (all variants pass WCAG AA)
- Add aria-label for screen readers
- Support keyboard navigation if clickable

```tsx
<div 
  className="..."
  role={onClick ? "button" : undefined}
  tabIndex={onClick ? 0 : undefined}
  onClick={onClick}
  aria-label={`${label}: ${value}`}
>
```

---

## 📱 Responsive Behavior

```tsx
// Desktop: 4 columns
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">

// Tablet: 2 columns
// Mobile: 1 column (stacked)
```

---

## 🎨 Advanced Features

### With Trend Indicator
```tsx
export function StatsCard({ label, value, icon: Icon, variant, trend }: StatsCardProps) {
  return (
    <div className="bg-white rounded-[12px] border border-[#EAECF0] p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[12px] text-[#667085] mb-1">{label}</p>
          <div className="flex items-baseline gap-2">
            <p className="text-[24px] font-bold text-[#101828]">{value}</p>
            {trend && (
              <span className={`text-[12px] font-medium ${trend.isPositive ? 'text-[#047857]' : 'text-[#DC2626]'}`}>
                {trend.isPositive ? '↑' : '↓'} {Math.abs(trend.value)}%
              </span>
            )}
          </div>
        </div>
        <div className={`w-10 h-10 rounded-full ${styles.bg} flex items-center justify-center`}>
          <Icon className={`w-5 h-5 ${styles.iconColor}`} />
        </div>
      </div>
    </div>
  );
}
```

### Clickable Card
```tsx
<StatsCard
  label="View Products"
  value={245}
  icon={Package}
  variant="primary"
  onClick={() => navigate('/products')}
/>

// Add hover effect in styles:
className={`... ${onClick ? 'cursor-pointer hover:shadow-lg transition-shadow' : ''}`}
```

---

## 🐛 Known Issues / Improvements

1. Add loading skeleton state
2. Add animation on value change
3. Support for custom icon sizes
4. Add tooltip for more details
5. Support for multiple values (compare last month)
6. Add export to CSV/PDF button

---

**Source File**: `/src/app/components/ProductsList.tsx` (lines 168-214)
**Dependencies**: `lucide-react`
**Used In**: ProductsList, Dashboard
**Last Updated**: January 15, 2026

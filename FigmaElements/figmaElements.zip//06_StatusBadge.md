# Canonical / Status Badge

## 📸 Visual Reference

Colored pill-shaped badges used to indicate status throughout the application. Common in tables, cards, and lists to show item states.

**Examples**:
- 🟢 **Đã đăng** (Published) - Green
- ⚪ **Đã ẩn** (Hidden) - Gray
- 🔴 **Vi phạm** (Violation) - Red
- 🟠 **Từ chối** (Rejected) - Orange
- 🟡 **Chờ duyệt** (Pending) - Yellow
- 🔵 **Nháp** (Draft) - Blue

---

## 📐 Specifications

### Container
- **Display**: Inline-flex or inline-block
- **Padding**: `px-2 py-0.5` or `px-2 py-1` (8px horizontal, 2-4px vertical)
- **Border Radius**: Full pill (`rounded-2xl` = 16px) or `rounded-full`
- **Font Size**: `var(--text-xs)` (11-12px)
- **Font Weight**: `var(--font-weight-medium)` (500)
- **Text Align**: Center
- **White Space**: nowrap

### Color Schemes

| Status | Label | Text Color | Background | Border | Use Case |
|--------|-------|------------|------------|--------|----------|
| Published | Đã đăng | `#027948` | `#D1FADF` | Optional | Active items |
| Hidden | Đã ẩn | `#667085` | `#F3F4F6` | Optional | Hidden items |
| Violation | Vi phạm | `#D92D20` | `#FEE4E2` | Optional | Rule violations |
| Rejected | Từ chối | `#C4320A` | `#FFF6ED` | Optional | Rejected items |
| Pending | Chờ duyệt | `#A65F00` | `#FEF9C2` | Optional | Awaiting approval |
| Draft | Nháp | `#175CD3` | `#EFF8FF` | Optional | Draft state |
| Active | Active | `#047857` | `#ECFDF5` | `#A7F3D0` | Product active |
| Inactive | Inactive | `#6B7280` | `#F3F4F6` | `#D1D5DB` | Product inactive |

---

## 💻 Component Code

### Basic Status Badge
```tsx
interface StatusBadgeProps {
  status: {
    label: string;
    color: string;
    bgColor: string;
    value?: string;
  };
  size?: 'sm' | 'md' | 'lg';
}

export function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const sizeClasses = {
    sm: 'px-1.5 py-0.5 text-[10px]',
    md: 'px-2 py-0.5 text-xs',
    lg: 'px-2 py-1 text-sm',
  };

  return (
    <span
      className={`${sizeClasses[size]} rounded-2xl font-medium inline-block`}
      style={{
        backgroundColor: status.bgColor,
        color: status.color,
      }}
    >
      {status.label}
    </span>
  );
}
```

### With Border
```tsx
interface StatusBadgeWithBorderProps {
  status: 0 | 1;
}

export function ProductStatusBadge({ status }: StatusBadgeWithBorderProps) {
  const styles = {
    1: {
      bg: 'bg-[#ECFDF5]',
      text: 'text-[#047857]',
      border: 'border-[#A7F3D0]',
      label: 'Active',
    },
    0: {
      bg: 'bg-[#F3F4F6]',
      text: 'text-[#6B7280]',
      border: 'border-[#D1D5DB]',
      label: 'Inactive',
    },
  };

  const style = styles[status];

  return (
    <span className={`px-2 py-1 rounded-full text-[11px] font-medium border ${style.bg} ${style.text} ${style.border}`}>
      {style.label}
    </span>
  );
}
```

### Predefined Status Types
```tsx
type VideoStatus = 'published' | 'hidden' | 'violation' | 'rejected' | 'pending' | 'draft';

const VIDEO_STATUS_CONFIG: Record<VideoStatus, { label: string; color: string; bgColor: string }> = {
  published: {
    label: 'Đã đăng',
    color: '#027948',
    bgColor: '#D1FADF',
  },
  hidden: {
    label: 'Đã ẩn',
    color: '#667085',
    bgColor: '#F3F4F6',
  },
  violation: {
    label: 'Vi phạm',
    color: '#D92D20',
    bgColor: '#FEE4E2',
  },
  rejected: {
    label: 'Từ chối',
    color: '#C4320A',
    bgColor: '#FFF6ED',
  },
  pending: {
    label: 'Chờ duyệt',
    color: '#A65F00',
    bgColor: '#FEF9C2',
  },
  draft: {
    label: 'Nháp',
    color: '#175CD3',
    bgColor: '#EFF8FF',
  },
};

export function VideoStatusBadge({ status }: { status: VideoStatus }) {
  const config = VIDEO_STATUS_CONFIG[status];
  
  return (
    <span
      className="px-2 py-0.5 rounded-2xl text-xs font-medium inline-block"
      style={{
        backgroundColor: config.bgColor,
        color: config.color,
      }}
    >
      {config.label}
    </span>
  );
}
```

### With Icon
```tsx
import { Check, X, Clock, AlertTriangle } from 'lucide-react';

const STATUS_ICONS = {
  published: Check,
  rejected: X,
  pending: Clock,
  violation: AlertTriangle,
};

export function StatusBadgeWithIcon({ status }: { status: VideoStatus }) {
  const config = VIDEO_STATUS_CONFIG[status];
  const Icon = STATUS_ICONS[status];

  return (
    <span
      className="px-2 py-0.5 rounded-2xl text-xs font-medium inline-flex items-center gap-1"
      style={{
        backgroundColor: config.bgColor,
        color: config.color,
      }}
    >
      {Icon && <Icon className="w-3 h-3" />}
      {config.label}
    </span>
  );
}
```

---

## 🎛️ Props API

```tsx
interface StatusBadgeProps {
  // Status object with color configuration
  status: {
    label: string;      // Display text
    color: string;      // Text color (hex)
    bgColor: string;    // Background color (hex)
    value?: string;     // Optional: internal value
  };
  
  // Or use predefined status type
  statusType?: 'published' | 'hidden' | 'violation' | 'rejected' | 'pending' | 'draft';
  
  // Optional: Size variant
  size?: 'sm' | 'md' | 'lg';
  
  // Optional: With border
  bordered?: boolean;
  
  // Optional: With icon
  icon?: React.ComponentType<{ className?: string }>;
  
  // Optional: Click handler (for interactive badges)
  onClick?: () => void;
  
  // Optional: Custom className
  className?: string;
}
```

---

## 📝 Usage Examples

### In Table
```tsx
<td className="px-4 py-4">
  <div className="flex justify-center">
    <StatusBadge 
      status={{
        label: 'Đã đăng',
        color: '#027948',
        bgColor: '#D1FADF',
        value: 'published',
      }}
    />
  </div>
</td>
```

### With Predefined Type
```tsx
<VideoStatusBadge status="published" />
<VideoStatusBadge status="pending" />
<VideoStatusBadge status="violation" />
```

### Product Status
```tsx
<ProductStatusBadge status={product.status} />
```

### With Custom Styling
```tsx
<StatusBadge
  status={customStatus}
  size="lg"
  className="shadow-sm"
/>
```

### Interactive Badge
```tsx
<button 
  onClick={() => changeStatus(item.id)}
  className="focus:outline-none focus:ring-2 focus:ring-offset-1"
>
  <StatusBadge status={item.status} />
</button>
```

---

## 🎨 Variants

### 1. Video Status Badges
```tsx
// Published - Green
{ label: 'Đã đăng', color: '#027948', bgColor: '#D1FADF' }

// Hidden - Gray
{ label: 'Đã ẩn', color: '#667085', bgColor: '#F3F4F6' }

// Pending - Yellow
{ label: 'Chờ duyệt', color: '#A65F00', bgColor: '#FEF9C2' }
```

### 2. Product Status Badges
```tsx
// Active - Green with border
<span className="px-2 py-1 rounded-full text-[11px] font-medium border bg-[#ECFDF5] text-[#047857] border-[#A7F3D0]">
  Active
</span>

// Inactive - Gray with border
<span className="px-2 py-1 rounded-full text-[11px] font-medium border bg-[#F3F4F6] text-[#6B7280] border-[#D1D5DB]">
  Inactive
</span>
```

### 3. Small Badge
```tsx
<StatusBadge status={status} size="sm" />
// px-1.5 py-0.5 text-[10px]
```

### 4. Large Badge
```tsx
<StatusBadge status={status} size="lg" />
// px-2 py-1 text-sm
```

---

## 🔧 Customization with CSS Variables

While current implementation uses inline styles, here's how to migrate to CSS variables:

```css
:root {
  /* Status colors */
  --status-published-bg: #D1FADF;
  --status-published-text: #027948;
  
  --status-hidden-bg: #F3F4F6;
  --status-hidden-text: #667085;
  
  --status-danger-bg: #FEE4E2;
  --status-danger-text: #D92D20;
  
  --status-warning-bg: #FEF9C2;
  --status-warning-text: #A65F00;
  
  --status-info-bg: #EFF8FF;
  --status-info-text: #175CD3;
}
```

Then use classes:
```tsx
<span className="px-2 py-0.5 rounded-2xl text-xs font-medium bg-[var(--status-published-bg)] text-[var(--status-published-text)]">
  Đã đăng
</span>
```

---

## ♿ Accessibility

- Use semantic colors (not just red/green for colorblind users)
- Add text labels, not just colors
- For interactive badges, add proper focus states
- Use `aria-label` if status value differs from label

```tsx
<span
  role="status"
  aria-label={`Status: ${status.label}`}
  className="..."
>
  {status.label}
</span>
```

---

## 📱 Responsive Behavior

Badges typically don't need responsive behavior, but you can:

```tsx
// Hide label on mobile, show icon only
<span className="px-2 py-0.5 rounded-2xl text-xs font-medium">
  <Icon className="w-3 h-3 md:hidden" />
  <span className="hidden md:inline">{status.label}</span>
</span>
```

---

## 🎨 Advanced Features

### Animated Badge
```tsx
export function AnimatedStatusBadge({ status }: StatusBadgeProps) {
  return (
    <span
      className="px-2 py-0.5 rounded-2xl text-xs font-medium inline-block transition-all duration-200 hover:scale-105"
      style={{
        backgroundColor: status.bgColor,
        color: status.color,
      }}
    >
      {status.label}
    </span>
  );
}
```

### With Tooltip
```tsx
import { Tooltip } from '@/app/components/ui/tooltip';

<Tooltip content="Click to change status">
  <button>
    <StatusBadge status={status} />
  </button>
</Tooltip>
```

### With Dot Indicator
```tsx
<span className="px-2 py-0.5 rounded-2xl text-xs font-medium inline-flex items-center gap-1.5">
  <span 
    className="w-1.5 h-1.5 rounded-full"
    style={{ backgroundColor: status.color }}
  />
  {status.label}
</span>
```

---

## 🐛 Known Issues / Improvements

1. Migrate from inline styles to CSS classes for better performance
2. Add animation on status change
3. Add status change dropdown for interactive badges
4. Support for custom status configurations
5. Add dark mode support
6. Add keyboard shortcuts for status changes
7. Add status history/log

---

**Source Files**: 
- `/src/app/components/VideoTable.tsx` (Video statuses)
- `/src/app/components/ProductsList.tsx` (Product statuses)
**Used In**: Tables, Cards, Lists, Detail Views
**Last Updated**: January 15, 2026

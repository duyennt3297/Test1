# Canonical / Action Buttons

## 📸 Visual Reference

Primary and secondary action buttons used throughout the application. Includes icon buttons, text buttons, and combined buttons.

**Categories**:
1. **Primary Button** - Main call-to-action (CTA)
2. **Secondary Button** - Alternative actions
3. **Destructive Button** - Delete/Remove actions
4. **Icon Button** - Icon-only actions
5. **Outline Button** - Bordered buttons

---

## 📐 Specifications

### Primary Button
- **Background**: `var(--primary)` (#7F56D9) or `#2563EB` or `#E50914` (destructive red)
- **Text Color**: White (#FFFFFF)
- **Padding**: `px-4 py-2` or `px-5 py-2`
- **Border Radius**: `rounded-lg` (8px)
- **Font Size**: `var(--text-sm)` (14px)
- **Font Weight**: `var(--font-weight-medium)` (500)
- **Hover**: opacity-90
- **Transition**: All properties

### Icon Button
- **Size**: Icon 16x16px (w-4 h-4) + padding 6px (p-1.5) = 28x28px total
- **Background**: Transparent
- **Hover**: `bg-[#F2F4F7]` or `bg-[#F9FAFB]`
- **Border Radius**: `rounded` (4px)
- **Icon Color**: `var(--muted-foreground)` (#667085)
- **Transition**: All 200ms

### Outline Button
- **Border**: 1px solid `var(--border)` (#D0D5DD) or specific color
- **Background**: Transparent or white
- **Text Color**: Matches border color
- **Hover**: Background fill with light tint

---

## 💻 Component Code

### Primary Button
```tsx
import { Plus } from 'lucide-react';

interface PrimaryButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  icon?: React.ComponentType<{ className?: string }>;
  variant?: 'primary' | 'destructive' | 'success';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
}

export function PrimaryButton({ 
  children, 
  onClick, 
  icon: Icon,
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
}: PrimaryButtonProps) {
  const variantStyles = {
    primary: 'bg-[#2563EB]',
    destructive: 'bg-[#E50914]',
    success: 'bg-[#047857]',
  };

  const sizeStyles = {
    sm: 'px-3 py-1.5 text-[13px]',
    md: 'px-4 py-2 text-[14px]',
    lg: 'px-5 py-2.5 text-[15px]',
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className={`
        ${variantStyles[variant]}
        ${sizeStyles[size]}
        text-white rounded-lg flex items-center gap-2 
        hover:opacity-90 transition-opacity
        disabled:opacity-50 disabled:cursor-not-allowed
        font-medium
      `}
    >
      {loading ? (
        <Loader2 className="w-4 h-4 animate-spin" />
      ) : Icon ? (
        <Icon className="w-4 h-4" />
      ) : null}
      <span>{children}</span>
    </button>
  );
}
```

### Icon Button
```tsx
import { Edit2, Trash2, Eye } from 'lucide-react';

interface IconButtonProps {
  icon: React.ComponentType<{ className?: string }>;
  onClick?: () => void;
  title?: string;
  variant?: 'default' | 'danger' | 'success';
  size?: 'sm' | 'md';
}

export function IconButton({ 
  icon: Icon, 
  onClick, 
  title,
  variant = 'default',
  size = 'md',
}: IconButtonProps) {
  const variantStyles = {
    default: 'text-[#667085] hover:text-[#344054] hover:bg-[#F2F4F7]',
    danger: 'text-[#DC2626] hover:text-[#B91C1C] hover:bg-[#FEF2F2]',
    success: 'text-[#047857] hover:text-[#065F46] hover:bg-[#ECFDF5]',
  };

  const sizeStyles = {
    sm: 'p-1',
    md: 'p-1.5',
  };

  const iconSizes = {
    sm: 'w-3.5 h-3.5',
    md: 'w-4 h-4',
  };

  return (
    <button
      onClick={onClick}
      title={title}
      className={`
        ${variantStyles[variant]}
        ${sizeStyles[size]}
        rounded transition-colors
      `}
    >
      <Icon className={iconSizes[size]} />
    </button>
  );
}
```

### Outline Button
```tsx
interface OutlineButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'default' | 'danger';
  icon?: React.ComponentType<{ className?: string }>;
}

export function OutlineButton({ 
  children, 
  onClick, 
  variant = 'default',
  icon: Icon,
}: OutlineButtonProps) {
  const variantStyles = {
    default: 'border-[#D0D5DD] text-[#344054] hover:bg-[#F9FAFB]',
    danger: 'border-[#F24141] text-[#F24141] hover:bg-[#FEF2F2]',
  };

  return (
    <button
      onClick={onClick}
      className={`
        h-[36px] px-3 border rounded-lg text-sm font-medium 
        transition-colors flex items-center gap-2
        ${variantStyles[variant]}
      `}
    >
      {Icon && <Icon className="w-4 h-4" />}
      <span>{children}</span>
    </button>
  );
}
```

### Button Group
```tsx
export function ButtonGroup({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2">
      {children}
    </div>
  );
}
```

---

## 🎛️ Props API

```tsx
interface ButtonProps {
  // Button content
  children: React.ReactNode;
  
  // Click handler
  onClick?: () => void;
  
  // Visual variant
  variant?: 'primary' | 'secondary' | 'destructive' | 'outline' | 'ghost';
  
  // Size
  size?: 'sm' | 'md' | 'lg';
  
  // Icon (lucide-react component)
  icon?: React.ComponentType<{ className?: string }>;
  
  // Icon position
  iconPosition?: 'left' | 'right';
  
  // Disabled state
  disabled?: boolean;
  
  // Loading state
  loading?: boolean;
  
  // Full width
  fullWidth?: boolean;
  
  // Custom className
  className?: string;
  
  // HTML button type
  type?: 'button' | 'submit' | 'reset';
}
```

---

## 📝 Usage Examples

### Primary Action Button
```tsx
<PrimaryButton
  icon={Plus}
  onClick={() => createProduct()}
>
  Add Product
</PrimaryButton>
```

### Destructive Action
```tsx
<PrimaryButton
  variant="destructive"
  icon={Trash2}
  onClick={() => deleteItem()}
>
  Delete
</PrimaryButton>
```

### Icon Buttons in Table
```tsx
<div className="flex items-center justify-center gap-2">
  <IconButton
    icon={Eye}
    title="View"
    onClick={() => viewItem(item)}
  />
  <IconButton
    icon={Edit2}
    title="Edit"
    onClick={() => editItem(item)}
  />
  <IconButton
    icon={Trash2}
    title="Delete"
    variant="danger"
    onClick={() => deleteItem(item)}
  />
</div>
```

### Outline Buttons
```tsx
<div className="flex items-center gap-2">
  <OutlineButton variant="danger" onClick={handleHide}>
    Ẩn
  </OutlineButton>
  <OutlineButton variant="danger" onClick={handleDelete}>
    Xóa
  </OutlineButton>
</div>
```

### Upload Button
```tsx
<PrimaryButton
  variant="destructive"
  icon={Plus}
  onClick={onUploadClick}
>
  Đăng video
</PrimaryButton>
```

### Loading State
```tsx
<PrimaryButton loading={isLoading} onClick={handleSubmit}>
  {isLoading ? 'Saving...' : 'Save Changes'}
</PrimaryButton>
```

---

## 🎨 Variants

### 1. Primary Blue
```tsx
// ProductsList - Add Product button
<button className="bg-[#2563EB] text-white px-4 py-2 rounded-[8px]">
  Add Product
</button>
```

### 2. Destructive Red
```tsx
// VideoTable - Upload button
<button className="bg-[#E50914] text-white px-5 py-2 rounded-lg">
  Đăng video
</button>
```

### 3. Outline Danger
```tsx
// VideoTable - Action buttons
<button className="border border-[#F24141] text-[#F24141] hover:bg-[#FEF2F2]">
  Xóa
</button>
```

### 4. Icon Only
```tsx
// Table actions
<button className="p-1.5 hover:bg-[#F2F4F7] rounded text-[#667085]">
  <Trash2 className="w-4 h-4" />
</button>
```

### 5. Header Icon Button
```tsx
// Header - Home/Bell icons
<button className="p-2 hover:bg-[#f9fafb] rounded transition-colors">
  <Icon className="w-6 h-6" />
</button>
```

---

## 🔧 Customization with CSS Variables

```css
:root {
  --primary: rgba(37, 99, 235, 1);           /* Primary blue */
  --destructive: rgba(217, 45, 32, 1);       /* Destructive red */
  --primary-foreground: rgba(255, 255, 255, 1); /* White text */
  --muted: rgba(242, 244, 247, 1);           /* Hover background */
  --border: rgba(208, 213, 221, 1);          /* Border color */
}
```

Then use:
```tsx
<button className="bg-primary text-primary-foreground hover:bg-primary/90">
  Click Me
</button>
```

---

## ♿ Accessibility

```tsx
<button
  onClick={handleClick}
  aria-label="Delete item"
  disabled={isDisabled}
  type="button"
  className="..."
>
  <Trash2 className="w-4 h-4" aria-hidden="true" />
  <span className="sr-only">Delete</span>
</button>
```

- Always provide `aria-label` for icon-only buttons
- Use proper `type` attribute
- Ensure sufficient color contrast (WCAG AA)
- Add visible focus states
- Support keyboard navigation (Tab, Enter, Space)

---

## 📱 Responsive Behavior

```tsx
// Stack buttons on mobile
<div className="flex flex-col sm:flex-row gap-2">
  <PrimaryButton>Save</PrimaryButton>
  <OutlineButton>Cancel</OutlineButton>
</div>

// Full width on mobile
<PrimaryButton className="w-full sm:w-auto">
  Submit
</PrimaryButton>

// Hide text on mobile, show icon only
<button className="px-2 sm:px-4">
  <Icon className="w-4 h-4" />
  <span className="hidden sm:inline ml-2">Delete</span>
</button>
```

---

## 🎨 Real-World Examples

### Video Table Upload Button
```tsx
<button
  onClick={onUploadClick}
  className="bg-[#E50914] text-white px-5 py-2 rounded-lg flex items-center gap-2 hover:opacity-90 transition-opacity"
>
  <Plus className="w-5 h-5" />
  <span className="text-sm font-medium">Đăng video</span>
</button>
```

### Products List Add Button
```tsx
<button
  onClick={onCreateClick}
  className="flex items-center gap-2 px-4 py-2 bg-[#2563EB] text-white rounded-[8px] hover:opacity-90 transition-opacity"
>
  <Plus className="w-4 h-4" />
  <span className="text-[14px] font-medium">Add Product</span>
</button>
```

### Action Buttons in Table
```tsx
<div className="flex items-center justify-end gap-1">
  <button className="p-1.5 text-[#667085] hover:text-[#344054] hover:bg-[#F2F4F7] rounded">
    <Edit2 className="w-4 h-4" />
  </button>
  <button className="p-1.5 text-[#DC2626] hover:text-[#B91C1C] hover:bg-[#FEF2F2] rounded">
    <Trash2 className="w-4 h-4" />
  </button>
</div>
```

---

## 🐛 Known Issues / Improvements

1. Unify button styles across the app (currently using different reds: #E50914, #F24141, #DC2626)
2. Use UI library button component (`/src/app/components/ui/button.tsx`) consistently
3. Add ripple effect on click
4. Add tooltip for icon buttons
5. Support for button groups (connected buttons)
6. Add loading skeleton state
7. Keyboard shortcut hints

---

**Source Files**: 
- `/src/app/components/VideoTable.tsx`
- `/src/app/components/ProductsList.tsx`
- `/src/app/components/ui/button.tsx`
**Dependencies**: `lucide-react`
**Last Updated**: January 15, 2026

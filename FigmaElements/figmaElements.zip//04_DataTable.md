# Canonical / Data Table

## 📸 Visual Reference

A comprehensive data table with sortable columns, row selection, filters, and pagination. Features alternating row colors, action buttons, and status badges.

**Used in**: VideoTable, ProductsList

---

## 📐 Specifications

### Container
- **Background**: `var(--card)` (#FFFFFF)
- **Border**: 1px solid `var(--border)` (#D0D5DD)
- **Border Radius**: `rounded-lg` (8px)
- **Overflow**: Hidden

### Table Header
- **Background**: `var(--muted)` (#F9FAFB) or white
- **Border Bottom**: 1px solid `var(--border)` (#D0D5DD)
- **Padding**: `px-4 py-2.5`
- **Font Size**: `var(--text-sm)` (14px)
- **Font Weight**: `var(--font-weight-medium)` (500)
- **Text Color**: `var(--foreground)` (#101828)
- **Text Transform**: None (or uppercase for some designs)

### Table Body
- **Row Padding**: `px-4 py-4` (or `py-3` for compact)
- **Font Size**: `var(--text-sm)` (14px)
- **Alternating Rows**:
  - Even: `bg-[#F9FAFB]`
  - Odd: `bg-white`
- **Hover**: `hover:bg-[#F9FAFB]` with transition

### Cells
- **Text Alignment**: 
  - Left: Default, text content
  - Center: Status, icons, images
  - Right: Numbers, metrics
- **Text Color**: `var(--foreground)` (#101828)
- **Muted Text**: `var(--muted-foreground)` (#667085)

### Checkbox
- **Size**: 16x16px
- **Border**: `var(--border)` (#D0D5DD)
- **Checked**: Same as border color
- **Border Radius**: 4px (rounded)

### Action Buttons
- **Size**: Icon 16x16px (w-4 h-4) + padding 6px (p-1.5) = 28x28px total
- **Hover**: `hover:bg-[#F2F4F7]`
- **Border Radius**: 4px (rounded)
- **Icon Color**: `var(--muted-foreground)` (#667085)

---

## 💻 Component Code

### Video Table Version

```tsx
import { Eye, Pencil, Trash2, EyeOff } from 'lucide-react';
import { useState } from 'react';

interface Video {
  id: number;
  thumbnail: string;
  title: string;
  status: {
    label: string;
    color: string;
    bgColor: string;
    value: string;
  };
  metrics: {
    value1: number;
    value2: number;
    value3: number | string;
    value4: number;
    value5: number;
  };
  date: string;
}

interface DataTableProps<T> {
  data: T[];
  columns: {
    key: string;
    label: string;
    align?: 'left' | 'center' | 'right';
    width?: string;
    render?: (item: T) => React.ReactNode;
  }[];
  onRowClick?: (item: T) => void;
  actions?: {
    icon: React.ComponentType<{ className?: string }>;
    label: string;
    onClick: (item: T) => void;
    variant?: 'default' | 'danger';
    show?: (item: T) => boolean;
  }[];
  selectable?: boolean;
  onSelectionChange?: (selectedIds: number[]) => void;
}

export function DataTable<T extends { id: number }>({
  data,
  columns,
  onRowClick,
  actions = [],
  selectable = false,
  onSelectionChange,
}: DataTableProps<T>) {
  const [selectedRows, setSelectedRows] = useState<number[]>([]);

  const toggleRow = (id: number) => {
    const newSelection = selectedRows.includes(id)
      ? selectedRows.filter(rowId => rowId !== id)
      : [...selectedRows, id];
    setSelectedRows(newSelection);
    onSelectionChange?.(newSelection);
  };

  const toggleAll = () => {
    const newSelection = selectedRows.length === data.length ? [] : data.map(item => item.id);
    setSelectedRows(newSelection);
    onSelectionChange?.(newSelection);
  };

  return (
    <div className="bg-white rounded-lg border border-[#D0D5DD] overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-white border-b border-[#D0D5DD]">
              {selectable && (
                <th className="px-4 py-2.5 w-[50px]">
                  <input
                    type="checkbox"
                    checked={selectedRows.length === data.length && data.length > 0}
                    onChange={toggleAll}
                    className="rounded border-[#D0D5DD] text-[#D0D5DD] focus:ring-0 focus:ring-offset-0"
                  />
                </th>
              )}
              {columns.map(column => (
                <th
                  key={column.key}
                  className={`px-4 py-2.5 text-${column.align || 'left'} text-[#101828] text-sm font-medium ${column.width || ''}`}
                >
                  {column.label}
                </th>
              ))}
              {actions.length > 0 && (
                <th className="px-4 py-2.5 text-center text-[#101828] text-sm font-medium">
                  Hành động
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {data.map((item, index) => (
              <tr
                key={item.id}
                className={index % 2 === 0 ? 'bg-[#F9FAFB]' : 'bg-white'}
              >
                {selectable && (
                  <td className="px-4 py-4">
                    <div className="flex justify-center">
                      <input
                        type="checkbox"
                        checked={selectedRows.includes(item.id)}
                        onChange={() => toggleRow(item.id)}
                        className="rounded border-[#D0D5DD] text-[#D0D5DD] focus:ring-0 focus:ring-offset-0"
                      />
                    </div>
                  </td>
                )}
                {columns.map(column => (
                  <td
                    key={column.key}
                    className={`px-4 py-4 text-${column.align || 'left'} text-[#101828] text-sm`}
                    onClick={() => onRowClick?.(item)}
                  >
                    {column.render ? column.render(item) : (item as any)[column.key]}
                  </td>
                ))}
                {actions.length > 0 && (
                  <td className="px-4 py-4">
                    <div className="flex items-center justify-center gap-2">
                      {actions.map((action, idx) => {
                        if (action.show && !action.show(item)) return null;
                        return (
                          <button
                            key={idx}
                            className={`p-1.5 hover:bg-[#F2F4F7] rounded transition-colors ${
                              action.variant === 'danger' ? 'text-[#DC2626]' : 'text-[#667085]'
                            }`}
                            title={action.label}
                            onClick={() => action.onClick(item)}
                          >
                            <action.icon className="w-4 h-4" />
                          </button>
                        );
                      })}
                    </div>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
```

### Products Table Version

```tsx
import { Edit2, Trash2, Package } from 'lucide-react';

interface Product {
  _id: string;
  title: string;
  sku?: string;
  price: number;
  compare_at_price?: number;
  stock_quantity: number;
  status: 0 | 1;
  featured_image_url?: string;
  brand?: string;
  tags?: string[];
}

export function ProductsTable({ products, onEdit, onDelete }: {
  products: Product[];
  onEdit: (id: string) => void;
  onDelete: (id: string, name: string) => void;
}) {
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
    }).format(amount);
  };

  const getStatusBadge = (status: Product['status']) => {
    const styles = {
      1: 'bg-[#ECFDF5] text-[#047857] border-[#A7F3D0]',
      0: 'bg-[#F3F4F6] text-[#6B7280] border-[#D1D5DB]',
    };

    const labels = {
      1: 'Active',
      0: 'Inactive',
    };

    return (
      <span className={`px-2 py-1 rounded-full text-[11px] font-medium border ${styles[status as 0 | 1]}`}>
        {labels[status as 0 | 1]}
      </span>
    );
  };

  return (
    <div className="bg-white rounded-[12px] border border-[#EAECF0] overflow-hidden">
      <table className="w-full">
        <thead className="bg-[#F9FAFB] border-b border-[#EAECF0]">
          <tr>
            <th className="px-4 py-3 text-left text-[12px] font-medium text-[#667085] uppercase tracking-wide">
              Product
            </th>
            <th className="px-4 py-3 text-left text-[12px] font-medium text-[#667085] uppercase tracking-wide">
              SKU
            </th>
            <th className="px-4 py-3 text-left text-[12px] font-medium text-[#667085] uppercase tracking-wide">
              Price
            </th>
            <th className="px-4 py-3 text-left text-[12px] font-medium text-[#667085] uppercase tracking-wide">
              Stock
            </th>
            <th className="px-4 py-3 text-left text-[12px] font-medium text-[#667085] uppercase tracking-wide">
              Status
            </th>
            <th className="px-4 py-3 text-right text-[12px] font-medium text-[#667085] uppercase tracking-wide">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#EAECF0]">
          {products.map(product => (
            <tr key={product._id} className="hover:bg-[#F9FAFB] transition-colors">
              <td className="px-4 py-3">
                <div className="flex items-center gap-3">
                  {product.featured_image_url ? (
                    <img
                      src={product.featured_image_url}
                      alt={product.title}
                      className="w-12 h-12 rounded-[8px] object-cover flex-shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-[8px] bg-[#F9FAFB] flex items-center justify-center flex-shrink-0">
                      <Package className="w-6 h-6 text-[#D0D5DD]" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <h3 className="text-[14px] font-medium text-[#101828] truncate">
                      {product.title}
                    </h3>
                    {product.brand && (
                      <p className="text-[12px] text-[#667085] truncate mt-0.5">
                        {product.brand}
                      </p>
                    )}
                  </div>
                </div>
              </td>
              <td className="px-4 py-3">
                <span className="text-[14px] text-[#344054] font-mono">
                  {product.sku || '-'}
                </span>
              </td>
              <td className="px-4 py-3">
                <div>
                  <p className="text-[14px] font-semibold text-[#101828]">
                    {formatCurrency(product.price)}
                  </p>
                  {product.compare_at_price && product.compare_at_price > product.price && (
                    <p className="text-[12px] text-[#667085] line-through">
                      {formatCurrency(product.compare_at_price)}
                    </p>
                  )}
                </div>
              </td>
              <td className="px-4 py-3">
                <span className="text-[14px] text-[#344054]">
                  {product.stock_quantity}
                </span>
              </td>
              <td className="px-4 py-3">
                {getStatusBadge(product.status)}
              </td>
              <td className="px-4 py-3">
                <div className="flex items-center justify-end gap-1">
                  <button 
                    onClick={() => onEdit(product._id)}
                    className="p-1.5 text-[#667085] hover:text-[#344054] hover:bg-[#F2F4F7] rounded"
                    title="Edit product"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => onDelete(product._id, product.title)}
                    className="p-1.5 text-[#DC2626] hover:text-[#B91C1C] hover:bg-[#FEF2F2] rounded"
                    title="Delete product"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
```

---

## 🎛️ Props API

```tsx
interface Column<T> {
  key: string;
  label: string;
  align?: 'left' | 'center' | 'right';
  width?: string;
  sortable?: boolean;
  render?: (item: T, index: number) => React.ReactNode;
}

interface ActionButton<T> {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  onClick: (item: T) => void;
  variant?: 'default' | 'danger' | 'success';
  show?: (item: T) => boolean;
}

interface DataTableProps<T> {
  // Data to display
  data: T[];
  
  // Column definitions
  columns: Column<T>[];
  
  // Optional: Row click handler
  onRowClick?: (item: T) => void;
  
  // Optional: Action buttons
  actions?: ActionButton<T>[];
  
  // Optional: Enable row selection
  selectable?: boolean;
  selectedRows?: number[];
  onSelectionChange?: (selectedIds: number[]) => void;
  
  // Optional: Loading state
  loading?: boolean;
  
  // Optional: Empty state
  emptyMessage?: string;
  
  // Optional: Sorting
  sortBy?: string;
  sortDirection?: 'asc' | 'desc';
  onSort?: (key: string) => void;
  
  // Optional: Pagination
  pagination?: {
    currentPage: number;
    totalPages: number;
    pageSize: number;
    totalRecords: number;
    onPageChange: (page: number) => void;
    onPageSizeChange: (size: number) => void;
  };
}
```

---

## 📝 Usage Examples

### Basic Table
```tsx
<DataTable
  data={products}
  columns={[
    { key: 'title', label: 'Product', align: 'left' },
    { key: 'sku', label: 'SKU', align: 'left' },
    { key: 'price', label: 'Price', align: 'right', render: (item) => formatCurrency(item.price) },
    { key: 'status', label: 'Status', align: 'center', render: (item) => getStatusBadge(item.status) },
  ]}
/>
```

### With Actions
```tsx
<DataTable
  data={videos}
  columns={columns}
  actions={[
    {
      icon: Eye,
      label: 'View',
      onClick: (video) => openVideo(video),
    },
    {
      icon: Trash2,
      label: 'Delete',
      onClick: (video) => deleteVideo(video),
      variant: 'danger',
    },
  ]}
/>
```

### With Selection
```tsx
<DataTable
  data={items}
  columns={columns}
  selectable
  selectedRows={selectedIds}
  onSelectionChange={setSelectedIds}
/>
```

---

## 🔧 Customization with CSS Variables

```css
:root {
  --card: rgba(255, 255, 255, 1);           /* Table background */
  --border: rgba(208, 213, 221, 1);         /* Borders */
  --muted: rgba(242, 244, 247, 1);          /* Header background */
  --foreground: rgba(16, 24, 40, 1);        /* Text color */
  --muted-foreground: rgba(102, 112, 133, 1); /* Muted text */
}
```

---

## ♿ Accessibility

- Use semantic `<table>` elements
- Proper `<th>` and `<td>` tags
- Add `scope` attribute to headers
- Keyboard navigation for checkboxes and actions
- ARIA labels for icon buttons
- Focus visible states

---

## 📱 Responsive Behavior

```tsx
// Horizontal scroll on small screens
<div className="overflow-x-auto">
  <table className="w-full min-w-[800px]">
```

Or use responsive utilities:

```tsx
// Hide columns on mobile
<th className="hidden md:table-cell">Desktop Only</th>
```

---

**Source Files**: 
- `/src/app/components/VideoTable.tsx`
- `/src/app/components/ProductsList.tsx`
**Dependencies**: `lucide-react`
**Last Updated**: January 15, 2026
